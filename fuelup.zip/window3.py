# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form3.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from credit import Ui_MainWindow
from fornet import Ui_netbanking
class Ui_Form(object):
    def openWindow3(self):
        self.window1 = QtWidgets.QMainWindow()
        self.uii = Ui_netbanking()
        self.uii.setupUi(self.window1)
        
        self.window1.show()
        
    def openWindow2(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self.window)
        
        self.window.show()
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(1151, 681)
        self.label = QtWidgets.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(180, 100, 111, 21))
        self.label.setObjectName("label")
        self.rupees = QtWidgets.QTextEdit(Form)
        self.rupees.setGeometry(QtCore.QRect(370, 100, 201, 31))
        self.rupees.setObjectName("rupees")
        self.label_2 = QtWidgets.QLabel(Form)
        self.label_2.setGeometry(QtCore.QRect(460, 160, 70, 21))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(Form)
        self.label_3.setGeometry(QtCore.QRect(180, 200, 121, 21))
        self.label_3.setObjectName("label_3")
        self.fuelqty = QtWidgets.QTextEdit(Form)
        self.fuelqty.setGeometry(QtCore.QRect(370, 200, 201, 31))
        self.fuelqty.setObjectName("fuelqty")
        self.label_5 = QtWidgets.QLabel(Form)
        self.label_5.setGeometry(QtCore.QRect(680, 160, 151, 21))
        self.label_5.setObjectName("label_5")
        self.ttlamt = QtWidgets.QTextEdit(Form)
        self.ttlamt.setGeometry(QtCore.QRect(830, 150, 261, 31))
        self.ttlamt.setObjectName("ttlamt")
        self.label_6 = QtWidgets.QLabel(Form)
        self.label_6.setGeometry(QtCore.QRect(420, 260, 211, 71))
        self.label_6.setObjectName("label_6")
        #self.pay = QtWidgets.QPushButton(Form)
    #self.pay.setGeometry(QtCore.QRect(820, 450, 112, 34))
        #self.pay.setObjectName("pay")
        self.label_4 = QtWidgets.QLabel(Form)
        self.label_4.setGeometry(QtCore.QRect(580, 100, 70, 21))
        self.label_4.setObjectName("label_4")
        self.widget = QtWidgets.QWidget(Form)
        self.widget.setGeometry(QtCore.QRect(410, 340, 271, 281))
        self.widget.setObjectName("widget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.widget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.credit = QtWidgets.QRadioButton(self.widget)
        self.credit.setObjectName("credit")
        self.verticalLayout.addWidget(self.credit)
        self.credit.clicked.connect(self.openWindow2)
        self.debit = QtWidgets.QRadioButton(self.widget)
        self.debit.setObjectName("debit")
        self.verticalLayout.addWidget(self.debit)
        self.debit.clicked.connect(self.openWindow2)
        #self.upi = QtWidgets.QRadioButton(self.widget)
        #self.upi.setObjectName("upi")
        #self.verticalLayout.addWidget(self.upi)
        self.netbanking = QtWidgets.QRadioButton(self.widget)
        self.netbanking.setObjectName("netbanking")
        self.verticalLayout.addWidget(self.netbanking)
        self.netbanking.clicked.connect(self.openWindow3)
        self.label.raise_()
        self.rupees.raise_()
        self.label_2.raise_()
        self.label_3.raise_()
        self.fuelqty.raise_()
        self.label_4.raise_()
        self.label_4.raise_()
        self.debit.raise_()
        #self.upi.raise_()
        self.netbanking.raise_()
        self.credit.raise_()
        self.label_5.raise_()
        self.ttlamt.raise_()
        self.label_6.raise_()
       # self.pay.raise_()

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label.setText(_translate("Form", "Enter Rupees"))
        self.label_2.setText(_translate("Form", "OR"))
        self.label_3.setText(_translate("Form", "Enter Fuel Qty."))
        self.label_5.setText(_translate("Form", "Amount To Pay is"))
        self.label_6.setText(_translate("Form", "<html><head/><body><p align=\"center\"><span style=\" font-size:24pt; font-weight:600; font-style:italic; text-decoration: underline;\">Pay By</span></p></body></html>"))
        #self.pay.setText(_translate("Form", "Pay"))
        self.label_4.setText(_translate("Form", "Rs."))
        self.credit.setText(_translate("Form", "Credit Card"))
        self.debit.setText(_translate("Form", "Debit Card"))
        #self.upi.setText(_translate("Form", "Paytm UPI"))
        self.netbanking.setText(_translate("Form", "Net Banking"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = Ui_Form()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())

