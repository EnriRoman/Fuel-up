# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form2.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from window3 import Ui_Form
class Ui_Form2(object):
    def openWindow1(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = Ui_Form()
        self.ui.setupUi(self.window)
        
        self.window.show()
        
        
    def setupUi(self, Form2):
        Form2.setObjectName("Form2")
        Form2.resize(1092, 801)
        self.label = QtWidgets.QLabel(Form2)
        self.label.setGeometry(QtCore.QRect(370, 120, 334, 48))
        self.label.setObjectName("label")
        self.widget = QtWidgets.QWidget(Form2)
        self.widget.setGeometry(QtCore.QRect(320, 280, 501, 341))
        self.widget.setObjectName("widget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.widget)
        self.verticalLayout.setContentsMargins(25, 25, 25, 25)
        self.verticalLayout.setSpacing(20)
        self.verticalLayout.setObjectName("verticalLayout")
        self.petrol = QtWidgets.QPushButton(self.widget)
        self.petrol.setObjectName("petrol")
        self.petrol.clicked.connect(self.openWindow1)
        
        self.verticalLayout.addWidget(self.petrol)
        self.diesel = QtWidgets.QPushButton(self.widget)
        self.diesel.setObjectName("diesel")
        self.diesel.clicked.connect(self.openWindow1)

        self.verticalLayout.addWidget(self.diesel)
        self.cng = QtWidgets.QPushButton(self.widget)
        self.cng.setObjectName("cng")
        self.verticalLayout.addWidget(self.cng)
        self.cng.clicked.connect(self.openWindow1)

        self.retranslateUi(Form2)
        QtCore.QMetaObject.connectSlotsByName(Form2)

    def retranslateUi(self, Form2):
        _translate = QtCore.QCoreApplication.translate
        Form2.setWindowTitle(_translate("Form2", "Form"))
        self.label.setText(_translate("Form2", "<html><head/><body><p align=\"center\"><span style=\" font-size:20pt; font-weight:600; font-style:italic; text-decoration: underline; color:#00aa00;\">Select Fuel Type</span></p></body></html>"))
        self.petrol.setText(_translate("Form2", "Petrol"))
        self.diesel.setText(_translate("Form2", "Diesel"))
        self.cng.setText(_translate("Form2", "CNG"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form2 = QtWidgets.QWidget()
    ui = Ui_Form2()
    ui.setupUi(Form2)
    Form2.show()
    sys.exit(app.exec_())

