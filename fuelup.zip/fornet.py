# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'fornet.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_netbanking(object):
    def setupUi(self, netbanking):
        netbanking.setObjectName("netbanking")
        netbanking.resize(859, 608)
        self.radioButton = QtWidgets.QRadioButton(netbanking)
        self.radioButton.setGeometry(QtCore.QRect(130, 230, 124, 25))
        self.radioButton.setObjectName("radioButton")
        self.label_3 = QtWidgets.QLabel(netbanking)
        self.label_3.setGeometry(QtCore.QRect(150, 360, 81, 21))
        self.label_3.setObjectName("label_3")
        self.radioButton_4 = QtWidgets.QRadioButton(netbanking)
        self.radioButton_4.setGeometry(QtCore.QRect(620, 230, 124, 25))
        self.radioButton_4.setObjectName("radioButton_4")
        self.label = QtWidgets.QLabel(netbanking)
        self.label.setGeometry(QtCore.QRect(140, 80, 211, 51))
        font = QtGui.QFont()
        font.setFamily("Nirmala UI")
        font.setPointSize(20)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(netbanking)
        self.label_2.setGeometry(QtCore.QRect(140, 180, 101, 21))
        self.label_2.setObjectName("label_2")
        self.lineEdit_2 = QtWidgets.QLineEdit(netbanking)
        self.lineEdit_2.setGeometry(QtCore.QRect(300, 430, 113, 27))
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.radioButton_2 = QtWidgets.QRadioButton(netbanking)
        self.radioButton_2.setGeometry(QtCore.QRect(290, 230, 124, 25))
        self.radioButton_2.setObjectName("radioButton_2")
        self.radioButton_3 = QtWidgets.QRadioButton(netbanking)
        self.radioButton_3.setGeometry(QtCore.QRect(450, 230, 124, 25))
        self.radioButton_3.setObjectName("radioButton_3")
        self.lineEdit = QtWidgets.QLineEdit(netbanking)
        self.lineEdit.setGeometry(QtCore.QRect(300, 360, 113, 27))
        self.lineEdit.setObjectName("lineEdit")
        self.label_4 = QtWidgets.QLabel(netbanking)
        self.label_4.setGeometry(QtCore.QRect(150, 430, 70, 21))
        self.label_4.setObjectName("label_4")

        self.retranslateUi(netbanking)
        QtCore.QMetaObject.connectSlotsByName(netbanking)

    def retranslateUi(self, netbanking):
        _translate = QtCore.QCoreApplication.translate
        netbanking.setWindowTitle(_translate("netbanking", "Form"))
        self.radioButton.setText(_translate("netbanking", "SBI"))
        self.label_3.setText(_translate("netbanking", "Username"))
        self.radioButton_4.setText(_translate("netbanking", "Other Banks"))
        self.label.setText(_translate("netbanking", "NetBanking"))
        self.label_2.setText(_translate("netbanking", "Select Bank"))
        self.radioButton_2.setText(_translate("netbanking", "ICICI"))
        self.radioButton_3.setText(_translate("netbanking", "AXIS"))
        self.label_4.setText(_translate("netbanking", "Password"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    netbanking = QtWidgets.QWidget()
    ui = Ui_netbanking()
    ui.setupUi(netbanking)
    netbanking.show()
    sys.exit(app.exec_())

