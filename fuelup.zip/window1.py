# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form1.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from window2 import Ui_Form2
class Ui_foem1(object):
    def openWindow(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = Ui_Form2()
        self.ui.setupUi(self.window)
        foem1.hide()
        self.window.show()
        
    def setupUi(self, foem1):
        foem1.setObjectName("foem1")
        foem1.resize(1106, 830)
        self.frontpage = QtWidgets.QLabel(foem1)
        self.frontpage.setGeometry(QtCore.QRect(420, 240, 251, 129))
        font = QtGui.QFont()
        font.setFamily("Arial Unicode MS")
        font.setPointSize(48)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.frontpage.setFont(font)
        self.frontpage.setObjectName("frontpage")
        self.goahead = QtWidgets.QPushButton(foem1)
        self.goahead.setGeometry(QtCore.QRect(480, 590, 190, 45))
        self.goahead.setObjectName("goahead")
        self.goahead.clicked.connect(self.openWindow)
        font = QtGui.QFont()
        font.setFamily("Modern No. 20")
        font.setPointSize(16)
        font.setBold(True)
        font.setItalic(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.goahead.setFont(font)
        self.goahead.setObjectName("goahead")
        self.dateTimeEdit = QtWidgets.QDateTimeEdit(foem1)
        self.dateTimeEdit.setGeometry(QtCore.QRect(870, 40, 121, 31))
        self.dateTimeEdit.setObjectName("dateTimeEdit")

        self.retranslateUi(foem1)
        QtCore.QMetaObject.connectSlotsByName(foem1)

    def retranslateUi(self, foem1):
        _translate = QtCore.QCoreApplication.translate
        foem1.setWindowTitle(_translate("foem1", "Form"))
        self.frontpage.setText(_translate("foem1", "<html><head/><body><p align=\"center\"><span style=\" font-weight:400; font-style:italic; color:#ff0000;\">Fuel</span></p></body></html>"))
        self.goahead.setText(_translate("foem1", "Go Ahead"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    foem1 = QtWidgets.QWidget()
    ui = Ui_foem1()
    ui.setupUi(foem1)
    foem1.show()
    sys.exit(app.exec_())

